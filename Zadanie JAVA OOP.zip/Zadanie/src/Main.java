class Address {
    private String ulica;
    private String miasto;
    private String kraj;

    public Address(String ulica, String miasto, String kraj) {
        this.ulica = ulica;
        this.miasto = miasto;
        this.kraj = kraj;
    }

    public String getUlica() {
        return ulica;
    }

    public void setUlica(String ulica) {
        this.ulica = ulica;
    }
    public String getMiasto() {
        return miasto;
    }
    public void setMiasto(String miasto) {
        this.miasto = miasto;
    }

    public String getKraj() {
        return kraj;
    }

    public void setKraj(String kraj) {
        this.kraj = kraj;
    }
}
class Dane {
    private String email;
    private int numerTelefonu;

    public Dane(String email, int numerTelefonu) {
        this.email = email;
        this.numerTelefonu = numerTelefonu;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getNumerTelefonu() {
        return numerTelefonu;
    }

    public void setNumerTelefonu(int numerTelefonu) {
        this.numerTelefonu = numerTelefonu;
    }
}

class Osoba {
    private String imie;
    private String nazwisko;
    private int wiek;
    private Address address;
    private Dane dane;
    public Osoba(String imie, String nazwisko, int wiek, Address address, Dane dane) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.wiek = wiek;
        this.address = address;
        this.dane = dane;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public int getWiek() {
        return wiek;
    }

    public void setWiek(int wiek) {
        this.wiek = wiek;
    }

    public String getAddress() {
        return address.getUlica() + ' ' + address.getMiasto() + ' ' + address.getKraj();
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getDane() {
        return dane.getEmail() + ' ' + dane.getNumerTelefonu();
    }

    public void setDane(Dane dane) {
        this.dane = dane;
    }

}
public class Main {
    public static void main(String[] args) {
        Address address1 = new Address("Bałtycka", "Olsztyn", "Polska");
        Dane dane1 = new Dane("abcd@gmail.com", 123456789);
        Osoba osoba = new Osoba("Adam", "Gaduła", 33, address1, dane1);

        System.out.println("Osoba 1: "+osoba.getImie() + ' ' + osoba.getNazwisko() + ' ' + osoba.getWiek()  + ", Adres zamieszkania: " + osoba.getAddress() + ", Kontakt: " + osoba.getDane());

        Address address2 = new Address("Krajowa", "Kraków", "Polska");
        Dane dane2 = new Dane("gar@gmail.com", 342156326);
        Osoba osoba2 = new Osoba("Ryszard", "Jacek", 21, address1, dane1);

        System.out.println("Osoba 2: "+osoba2.getImie() + ' ' + osoba2.getNazwisko() + ' ' + osoba2.getWiek()  + ", Adres zamieszkania: " + osoba2.getAddress() + ", Kontakt: " + osoba2.getDane());

        Address address3 = new Address("Limanowskiego", "Olsztyn", "Polska");
        Dane dane3 = new Dane("sssd@gmail.com", 421362378);
        Osoba osoba3 = new Osoba("Marian", "Gaduła", 56, address1, dane1);

        System.out.println("Osoba 3: "+osoba3.getImie() + ' ' + osoba3.getNazwisko() + ' ' + osoba3.getWiek()  + ", Adres zamieszkania: " + osoba3.getAddress() + ", Kontakt: " + osoba3.getDane());
    }
}