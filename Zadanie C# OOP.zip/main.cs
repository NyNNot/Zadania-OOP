using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace c_
{
    public class main
    {
        static void Main(string[] args){
            // Osoba 1
            Address address = new Address();
            address.setUlica("Bałtycka");
            address.setMiasto("Olsztyn");
            address.setKraj("Polska");
            Dane dane = new Dane();
            dane.setEmail("abcd@gmail.com");
            dane.setNumerTelefonu(123456789);
            Osoba osoba = new Osoba();
            osoba.setImie("Adam");
            osoba.setNazwisko("Gaduła");
            osoba.setWiek(34);

            //Osoba2
            Address address2 = new Address();
            address2.setUlica("Krajowa");
            address2.setMiasto("Kraków");
            address2.setKraj("Polska");
            Dane dane2 = new Dane();
            dane2.setEmail("gar@gmail.com");
            dane2.setNumerTelefonu(342156326);
            Osoba osoba2 = new Osoba();
            osoba2.setImie("Ryszard");
            osoba2.setNazwisko("Jacek");
            osoba2.setWiek(21);

            //Osoba3
            Address address3 = new Address();
            address3.setUlica("Limanowskiego");
            address3.setMiasto("Olsztyn");
            address3.setKraj("Polska");
            Dane dane3 = new Dane();
            dane3.setEmail("sssd@gmail.com");
            dane3.setNumerTelefonu(421362378);
            Osoba osoba3 = new Osoba();
            osoba3.setImie("Marian");
            osoba3.setNazwisko("Gaduła");
            osoba3.setWiek(56);

            Console.WriteLine("Osoba 1:");
            Console.WriteLine($"{osoba.getImie()}, {osoba.getNazwisko()}, {osoba.getWiek()}");
            Console.WriteLine($"Miejsce zamieszkania: {address.getUlica()}, {address.getMiasto()}, {address.getKraj()}");
            Console.WriteLine($"Dane: {dane.getEmail()}, {dane.getNumerTelefonu()}");

            Console.WriteLine("Osoba 2:");
            Console.WriteLine($"{osoba2.getImie()}, {osoba2.getNazwisko()}, {osoba2.getWiek()}");
            Console.WriteLine($"Miejsce zamieszkania: {address2.getUlica()}, {address2.getMiasto()}, {address2.getKraj()}");
            Console.WriteLine($"Dane: {dane2.getEmail()}, {dane2.getNumerTelefonu()}");

            Console.WriteLine("Osoba 3:");
            Console.WriteLine($"{osoba3.getImie()}, {osoba3.getNazwisko()}, {osoba3.getWiek()}");
            Console.WriteLine($"Miejsce zamieszkania: {address3.getUlica()}, {address3.getMiasto()}, {address3.getKraj()}");
            Console.WriteLine($"Dane: {dane3.getEmail()}, {dane3.getNumerTelefonu()}");
        }
    }
}