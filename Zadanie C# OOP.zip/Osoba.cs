using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace c_
{
    public class Osoba
    {
        public string imie;
        public string nazwisko;
        public int wiek;

        public string getImie() {
            return imie;
        }
        public void setImie(string im){
            imie = im;
        }
        public string getNazwisko() {
            return nazwisko;
        }
        public void setNazwisko(string nazwi){
            nazwisko = nazwi;
        }
        public int getWiek() {
            return wiek;
        }
        public void setWiek(int wk){
            wiek = wk;
        }
    }
}