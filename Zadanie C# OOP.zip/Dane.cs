using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace c_
{
    internal class Dane
    {
        public string email;
        public int numerTelefonu;

        public string getEmail() {
            return email;
        }
        public void setEmail(string em) {
            email = em;
        }
        public int getNumerTelefonu() {
            return numerTelefonu;
        }
        public void setNumerTelefonu(int numer) {
            numerTelefonu = numer;
        }
    }
}