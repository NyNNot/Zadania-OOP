using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace c_
{
    public class Address
    {
        public string ulica;
        public string miasto;
        public string kraj;

        public string getUlica() {
            return ulica;
        }
        public void setUlica(string ul){
            ulica = ul;
        }
        public string getMiasto() {
            return miasto;
        }
        public void setMiasto(string miast){
            miasto = miast;
        }
        public string getKraj() {
            return kraj;
        }
        public void setKraj(string kr){
            kraj = kr;
        }
    }
}