#include <iostream>
#include <string>
using namespace std;

class Address {
    public:
        string ulica;
        string miasto;
        string kraj;

        Address(string ul, string miast, string kr) : ulica(ul), miasto(miast), kraj(kr){}

        void setUlica(string ul) {
            ulica = ul;
        }
        string getUlica(){
            return ulica;
        }
        void setMiasto(string miast) {
            miasto = miast;
        }
        string getMiasto(){
            return miasto;
        }
        void setKraj(string kr) {
            kraj = kr;
        }
        string getKraj(){
            return kraj;
        }
};
class Dane {
    public:
        string email;
        int numerTelefonu;

        Dane(string em, int numer) : email(em), numerTelefonu(numer){}

        void setEmail(string em) {
            email = em;
        }
        string getEmail(){
            return email;
        }
        void setNumerTelefonu(int numer) {
            numerTelefonu = numer;
        }
        int getNumerTelefonu(){
            return numerTelefonu;
        }
};
class Osoba {
    public:
        string imie;
        string nazwisko;
        int wiek;

        Osoba(string im, string nazw, int wk) : imie(im), nazwisko(nazw), wiek(wk){}

        void setImie(string im) {
            imie = im;
        }
        string getImie(){
            return imie;
        }
        void setNazwisko(string nazw) {
            nazwisko = nazw;
        }
        string getNazwisko(){
            return nazwisko;
        }
        void setWiek(int wk) {
            wiek = wk;
        }
        int getWiek(){
            return wiek;
        }
};

int main() {
    Address address("Bałtycka", "Olsztyn", "Kraj");
    Dane dane("abcd@gmail.com", 123456789);
    Osoba osoba("Adam", "Gaduła", 34);
    cout << address.getUlica() +" "+ address.getMiasto() +" "+ address.getKraj()<<endl;
    cout << dane.getEmail() +" "+ to_string(dane.getNumerTelefonu())<<endl;
    cout << osoba.getImie() +" "+ osoba.getNazwisko() +" "+to_string(osoba.getWiek())<<endl;

    Address address2("Krajowa", "Kraków", "Kraj");
    Dane dane2("gar@gmail.com", 342156326);
    Osoba osoba2("Ryszard", "Jacek", 21);
    cout << address2.getUlica() +" "+ address2.getMiasto() +" "+ address2.getKraj()<<endl;
    cout << dane2.getEmail() +" "+ to_string(dane2.getNumerTelefonu())<<endl;
    cout << osoba2.getImie() +" "+ osoba2.getNazwisko() +" "+to_string(osoba2.getWiek())<<endl;

    Address address3("Krajowa", "Kraków", "Kraj");
    Dane dane3("gar@gmail.com", 342156326);
    Osoba osoba3("Ryszard", "Jacek", 21);
    cout << address3.getUlica() +" "+ address3.getMiasto() +" "+ address3.getKraj()<<endl;
    cout << dane3.getEmail() +" "+ to_string(dane3.getNumerTelefonu())<<endl;
    cout << osoba3.getImie() +" "+ osoba3.getNazwisko() +" "+to_string(osoba3.getWiek())<<endl;
    return 0;
}